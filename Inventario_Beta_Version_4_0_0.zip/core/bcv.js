// --- CONEXIÓN BCV API EN VIVO ---
async function obtenerTasaOficialBCV() {
    const lblTasa = document.getElementById('tasaActual');
    const lblFecha = document.getElementById('fechaActualizacion');
    const status = document.getElementById('bcv-sync-status');
    const fechaInventario = document.getElementById('inventario-fecha-tasa');
    const horaInventario = document.getElementById('inventario-hora-consulta');

    const setStatus = (tipo, texto, icono) => {
        if (!status) return;
        status.className = `bcv-sync-status ${tipo || ''}`;
        status.innerHTML = `<i class="fas ${icono}"></i> ${texto}`;
    };

    const formatearBs = (valor) => Number(valor).toLocaleString('es-VE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });

    const actualizarTarjetaInventario = () => {
        const usd = document.getElementById('inventario-tasa-usd');
        const eur = document.getElementById('inventario-tasa-eur');

        if (usd) usd.textContent = tasaUSD_BCV > 0 ? formatearBs(tasaUSD_BCV) : 'No disponible';
        if (eur) eur.textContent = tasaEUR_BCV > 0 ? formatearBs(tasaEUR_BCV) : 'No disponible';

        if (fechaInventario) {
            fechaInventario.textContent = fechaTasaBCV || 'No disponible';
        }

        if (horaInventario) {
            horaInventario.textContent = new Date().toLocaleTimeString('es-VE');
        }
    };

    try {
        setStatus('', 'Consultando BCV...', 'fa-sync-alt');

        /*
         * IMPORTANTE:
         * Se utilizan los endpoints públicos de BCV API.
         * No usamos el endpoint antiguo ve.boletinoficial.net porque puede
         * devolver una tasa distinta/desactualizada.
         *
         * Según la documentación de BCV API:
         * /api/v1/dolar/public
         * /api/v1/euro/public
         */
        const [usdRes, eurRes] = await Promise.all([
            fetch('https://bcvapi.tech/api/v1/dolar/public?ts=' + Date.now(), {
                method: 'GET',
                cache: 'no-store',
                headers: { 'Accept': 'application/json' }
            }),
            fetch('https://bcvapi.tech/api/v1/euro/public?ts=' + Date.now(), {
                method: 'GET',
                cache: 'no-store',
                headers: { 'Accept': 'application/json' }
            })
        ]);

        if (!usdRes.ok) throw new Error(`Dólar BCV API: HTTP ${usdRes.status}`);
        if (!eurRes.ok) throw new Error(`Euro BCV API: HTTP ${eurRes.status}`);

        const usdData = await usdRes.json();
        const eurData = await eurRes.json();

        const usd = parseFloat(usdData.tasa);
        const eur = parseFloat(eurData.tasa);

        if (!Number.isFinite(usd) || usd <= 0) {
            throw new Error('La API no devolvió una tasa USD válida.');
        }

        if (!Number.isFinite(eur) || eur <= 0) {
            throw new Error('La API no devolvió una tasa EUR válida.');
        }

        tasaUSD_BCV = usd;
        tasaEUR_BCV = eur;

        // La fecha pertenece a la tasa BCV, NO a la fecha/hora en que abriste el POS.
        fechaTasaBCV = usdData.fecha || eurData.fecha || 'Última tasa publicada por BCV';

        lblFecha.textContent = fechaTasaBCV;

        actualizarTarjetaInventario();
        actualizarVistaTasaBCV();

        setStatus('success', 'Tasa BCV actualizada', 'fa-check-circle');

        console.info('BCV actualizado:', {
            USD: tasaUSD_BCV,
            EUR: tasaEUR_BCV,
            fecha: fechaTasaBCV
        });

    } catch (error) {
        console.error('ERROR OBTENIENDO TASA BCV:', error);

        actualizarTarjetaInventario();

        // NO mostramos una tasa inventada ni una tasa antigua como si fuera actual.
        lblTasa.textContent = 'No disponible';
        lblFecha.textContent = 'No se pudo consultar BCV';

        setStatus('error', 'Error consultando BCV', 'fa-triangle-exclamation');

        // Si ya había una tasa válida cargada anteriormente durante esta sesión,
        // la conservamos, pero no la presentamos como una nueva actualización.
        if (tasaUSD_BCV > 0 && tasaEUR_BCV > 0) {
            actualizarVistaTasaBCV();
            lblFecha.textContent = fechaTasaBCV || 'Última tasa válida de esta sesión';
        }
    }
}

function seleccionarMonedaBCV(moneda) {
    monedaSeleccionada = moneda;
    document.getElementById('btn-usd').classList.toggle('active', moneda === 'USD');
    document.getElementById('btn-eur').classList.toggle('active', moneda === 'EUR');
    actualizarVistaTasaBCV();
}

function actualizarVistaTasaBCV() {
    const lblTasa = document.getElementById('tasaActual');

    if (monedaSeleccionada === 'USD') {
        tasaActiva = tasaUSD_BCV;
        lblTasa.textContent = `1 USD = ${tasaActiva.toFixed(2)} Bs`;
    } else {
        tasaActiva = tasaEUR_BCV;
        lblTasa.textContent = `1 EUR = ${tasaActiva.toFixed(2)} Bs`;
    }

    renderizarPosProductos();
    renderizarInventario();
    renderizarClientes();
    renderizarCarrito();
    if (clienteSeleccionadoId) verDetalleCliente(clienteSeleccionadoId);
}

function switchTab(tabId) {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.view-content').forEach(v => v.classList.remove('active'));
    
    event.target.classList.add('active');
    document.getElementById(tabId).classList.add('active');
}
